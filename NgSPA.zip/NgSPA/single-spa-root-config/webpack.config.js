const HtmlWebpackPlugin = require("html-webpack-plugin");
const { merge } = require("webpack-merge");
const singleSpaDefaults = require("webpack-config-single-spa"); 

module.exports = (webpackConfigEnv, argv) => {
    const defaultConfig = singleSpaDefaults({
        orgName: "myapp",
        projectName: "single-spa-root-config",
        webpackConfigEnv,
        argv,
    });

    return merge(defaultConfig, {
        entry: "./src/root-config.js",
        plugins: [
            new HtmlWebpackPlugin({
                template: "./src/index.ejs",
                filename: "index.ejs"
            })

        ],
    })
}