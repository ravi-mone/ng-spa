import { registerApplication, start } from "single-spa";

registerApplication({
    name:'gold-loan',
    app:()=>System.import('gold-loan'),
    activeWhen:(location)=> location.pathname.startsWith('gold-loan')
});

registerApplication({
    name:'vehicle-loan',
    app:()=>System.import('vehicle-loan'),
    activeWhen:(location)=> location.pathname.startsWith('vehicle-loan')
});

start();