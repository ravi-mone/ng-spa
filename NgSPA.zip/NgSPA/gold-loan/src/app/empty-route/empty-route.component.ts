import { Component } from '@angular/core';

@Component({
  selector: 'app-empty-route',
  template: '',
})
export class EmptyRouteComponent {}
